// Muestro saludo con alerta
alert("Hola!");