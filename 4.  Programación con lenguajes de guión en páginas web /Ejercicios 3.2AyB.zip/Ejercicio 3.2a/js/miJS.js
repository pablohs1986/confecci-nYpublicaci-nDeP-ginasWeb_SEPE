// Declaro variables
var nombre1, edad1, altura1;
var nombre2, edad2, altura2;

// Asigno valores a las variables
nombre1 = 'Pepe';
edad1 = 40;
altura1 = 1.60;

nombre2 = 'Pepa';
edad2 = 50;
altura2 = 1.70;

// Muestro el contenido en la página
document.write("Persona 1: " + nombre1 + edad1 + altura1);
document.write("<br>");
document.write("Persona 1: " + nombre1 + edad1 + altura1);
document.write("<br>");
document.write("<br>");

// Calculo la media de la edad
document.write("La media de edad es " + (edad1 + edad2)/2);
document.write("<br>");

// Calculo la media de la altura
document.write("La media de la altura es " + (altura1 + altura2)/2);